{
    "short_name": "TomatoTimer",
    "name": "TomatoTimer",
    "icons": [
        {
            "src": "/android-chrome-192x192.png",
            "sizes": "192x192",
            "type": "image/png"
        },
        {
            "src": "/android-chrome-384x384.png",
            "sizes": "384x384",
            "type": "image/png"
        }
    ],
    "start_url": ".",
    "orientation": "portrait",
    "theme_color": "#ffffff",
    "background_color": "#ffffff",
    "display": "standalone"
}